from django.apps import AppConfig


class GarageautomationConfig(AppConfig):
    name = 'garageAutomation'
