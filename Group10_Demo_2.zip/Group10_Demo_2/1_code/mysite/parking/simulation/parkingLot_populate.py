text_file1 = open("sensor_ids.txt", "w")
text_file2 = open("spot_numbers.txt", "w")
for i in range(1,301):
	
text_file.write("Purchase Amount: %s" % TotalAmount)
text_file.close()