package com.openalpr.api.invoker.auth;

public enum OAuthFlow {
    accessCode, implicit, password, application
}