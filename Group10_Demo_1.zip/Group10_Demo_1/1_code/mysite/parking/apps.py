from django.apps import AppConfig
#App configuration for parking.
class ParkingConfig(AppConfig):
    name = 'parking'
