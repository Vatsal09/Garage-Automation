from __future__ import unicode_literals

from django.apps import AppConfig


class Page2Config(AppConfig):
    name = 'page2'
