from __future__ import unicode_literals

from django.db import models

#import datetime
# Create your models here.

#class generateData():
#	transactionID
#	Amount
#	Date
	
#class displayTrans():

#class verify():
	

 
